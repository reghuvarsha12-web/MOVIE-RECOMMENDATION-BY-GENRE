# 🎬 Movie Recommendation by Genre
**FutureReady Hack · Project #119 · Domain: AI, APIs & Smart Applications**

A beginner-friendly, menu-driven Python app that recommends movies from a small local dataset based on the genres you select. Pure standard library (Matplotlib only for charts).

## Quick start
```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt   # only matplotlib; app still runs without it (charts disabled)
python main.py
```
Requires Python 3.10+. Run tests: `python -m unittest discover -s tests -v`

## Features
| Requirement | Where |
|---|---|
| Interactive terminal menu (ANSI colours, paginated tables) | `movierec/ui.py` |
| Defensive input validation (loops until valid; `cancel` to go back) | `movierec/validation.py`, `movierec/models.py` |
| Recommendation engine | `movierec/recommender.py` |
| JSON persistence + CSV export, corruption recovery | `movierec/storage.py` |
| Search by keyword / genre / rating | `movierec/search.py` |
| Executive summary (totals, averages, status, trend) | `movierec/summary.py` |
| Matplotlib charts (5 PNGs) | `movierec/plotting.py` |
| **Stretch:** Markdown / TXT audit log / CSV export | `movierec/exporter.py` |
| **Stretch:** Threshold warnings | `movierec/summary.py` → menu 10 |
| **Stretch:** Bulk CSV import with row-by-row error log | `movierec/importer.py` |

## How the recommendation score works
1. **Filter**: `any` mode = movie shares ≥1 selected genre; `all` mode = must contain every selected genre. Optional min rating / year / runtime filters.
2. **Weighted rating** (IMDb-style Bayesian average) so a 10.0 from 3 votes can't outrank a 9.0 from 2 million votes:
   `WR = v/(v+m)·R + m/(v+m)·C`  (m = 10,000 votes, C = dataset mean rating)
3. **Score (0-100)** = 60% weighted rating + 30% genre-match fraction + 10% recency.

## Data
* `data/movies.json` – live database (auto-created from `data/seed_movies.csv` if missing or corrupt; corrupt files are backed up as `*.corrupt-<timestamp>.json`).
* `data/seed_movies.csv` – 45 sample records: 40 real titles (approximate ratings/votes, demo only) + 5 fictional edge cases (0 rating, 10 rating with 3 votes, 420-min runtime, 5-min runtime, zero votes).
* `data/legacy_import_sample.csv` – messy CSV for the bulk-import demo (3 valid, 4 invalid, 1 duplicate).
* `data/history.json` – recommendation history (created on first use).
* `reports/` – charts, exports and import logs are written here.
* Regenerate the sample data: `cd tools && python make_seed.py`

## Suggested 5-minute demo script
1. Launch `python main.py` → show the branded welcome screen.
2. **Menu 4** Add a movie: type a blank title, year `1700`, rating `abc`, runtime `0` → show each rejection, then enter valid values.
3. **Menu 1** Recommend: pick `Sci-Fi Action`, try `all` vs `any` mode.
4. **Menu 6** Executive summary, then **Menu 10** warnings (edge-case records are flagged).
5. **Menu 9** Bulk import (press Enter for the sample) → show rejected rows + log file.
6. **Menu 7 / 8** Generate charts and export reports (open `reports/`).
7. **Menu 0** Exit, relaunch, **Menu 3** search for your new movie → persistence proven.
8. Optional robustness trick: corrupt `data/movies.json` (e.g. delete a bracket) and relaunch → app recovers automatically.

## Project layout
```
movie_recommender/
├── main.py                # entry point
├── requirements.txt
├── movierec/              # application package
├── data/                  # JSON db, seed CSV, import sample
├── reports/               # generated output
├── tests/test_core.py     # 11 unit tests
└── tools/make_seed.py     # dataset generator
```

## Ideas to extend
Tkinter/Textual front end, TMDB API fetch with local-cache fallback, per-user watched lists, content-based similarity (shared director/language), edit-record menu.
