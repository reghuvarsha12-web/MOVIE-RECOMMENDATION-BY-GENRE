"""Regenerates data/seed_movies.csv and data/movies.json (sample dataset, 44 records).
Ratings/votes are approximate and for demo purposes only."""
import csv, json
rows = [
 # title, genres, year, rating, votes, runtime, language, director
 ("The Shawshank Redemption","Drama",1994,9.3,2900000,142,"English","Frank Darabont"),
 ("The Godfather","Crime|Drama",1972,9.2,2000000,175,"English","Francis Ford Coppola"),
 ("The Dark Knight","Action|Crime|Thriller",2008,9.0,2900000,152,"English","Christopher Nolan"),
 ("Inception","Action|Sci-Fi|Thriller",2010,8.8,2600000,148,"English","Christopher Nolan"),
 ("Interstellar","Adventure|Drama|Sci-Fi",2014,8.7,2300000,169,"English","Christopher Nolan"),
 ("The Matrix","Action|Sci-Fi",1999,8.7,2100000,136,"English","Lana & Lilly Wachowski"),
 ("Pulp Fiction","Crime|Drama",1994,8.9,2200000,154,"English","Quentin Tarantino"),
 ("Forrest Gump","Drama|Romance",1994,8.8,2300000,142,"English","Robert Zemeckis"),
 ("Spirited Away","Animation|Adventure|Family|Fantasy",2001,8.6,850000,125,"Japanese","Hayao Miyazaki"),
 ("Parasite","Comedy|Drama|Thriller",2019,8.5,1000000,132,"Korean","Bong Joon-ho"),
 ("Toy Story","Animation|Adventure|Comedy|Family",1995,8.3,1100000,81,"English","John Lasseter"),
 ("The Lion King","Animation|Adventure|Family|Musical",1994,8.5,1100000,88,"English","Roger Allers"),
 ("Gladiator","Action|Adventure|Drama",2000,8.5,1600000,155,"English","Ridley Scott"),
 ("Schindler's List","Biography|Drama|War",1993,9.0,1450000,195,"English","Steven Spielberg"),
 ("Saving Private Ryan","Drama|War",1998,8.6,1500000,169,"English","Steven Spielberg"),
 ("The Silence of the Lambs","Crime|Drama|Horror|Thriller",1991,8.6,1500000,118,"English","Jonathan Demme"),
 ("Get Out","Horror|Mystery|Thriller",2017,7.8,680000,104,"English","Jordan Peele"),
 ("The Shining","Drama|Horror",1980,8.4,1100000,146,"English","Stanley Kubrick"),
 ("Knives Out","Comedy|Crime|Mystery",2019,7.9,650000,130,"English","Rian Johnson"),
 ("Se7en","Crime|Mystery|Thriller",1995,8.6,1900000,127,"English","David Fincher"),
 ("La La Land","Comedy|Drama|Musical|Romance",2016,8.0,700000,128,"English","Damien Chazelle"),
 ("Titanic","Drama|Romance",1997,7.9,1300000,195,"English","James Cameron"),
 ("The Notebook","Drama|Romance",2004,7.8,600000,123,"English","Nick Cassavetes"),
 ("Mad Max: Fury Road","Action|Adventure|Sci-Fi",2015,8.1,1100000,120,"English","George Miller"),
 ("Blade Runner 2049","Drama|Mystery|Sci-Fi",2017,8.0,640000,164,"English","Denis Villeneuve"),
 ("Dune","Action|Adventure|Drama|Sci-Fi",2021,8.0,750000,155,"English","Denis Villeneuve"),
 ("The Lord of the Rings: The Fellowship of the Ring","Adventure|Drama|Fantasy",2001,8.8,2000000,178,"English","Peter Jackson"),
 ("Harry Potter and the Sorcerer's Stone","Adventure|Family|Fantasy",2001,7.6,800000,152,"English","Chris Columbus"),
 ("Coco","Animation|Adventure|Family|Fantasy|Musical",2017,8.4,590000,105,"English","Lee Unkrich"),
 ("Finding Nemo","Animation|Adventure|Comedy|Family",2003,8.2,1100000,100,"English","Andrew Stanton"),
 ("Superbad","Comedy",2007,7.6,640000,113,"English","Greg Mottola"),
 ("The Grand Budapest Hotel","Adventure|Comedy|Crime",2014,8.1,900000,99,"English","Wes Anderson"),
 ("3 Idiots","Comedy|Drama",2009,8.4,420000,170,"Hindi","Rajkumar Hirani"),
 ("Dangal","Action|Biography|Drama",2016,8.3,200000,161,"Hindi","Nitesh Tiwari"),
 ("RRR","Action|Drama",2022,7.8,150000,182,"Telugu","S. S. Rajamouli"),
 ("Baahubali: The Beginning","Action|Drama|Fantasy",2015,8.0,130000,159,"Telugu","S. S. Rajamouli"),
 ("Lagaan","Adventure|Drama|Musical",2001,8.1,120000,224,"Hindi","Ashutosh Gowariker"),
 ("A Quiet Place","Drama|Horror|Sci-Fi",2018,7.5,600000,90,"English","John Krasinski"),
 ("Whiplash","Drama|Musical",2014,8.5,1000000,106,"English","Damien Chazelle"),
 ("1917","Action|Drama|War",2019,8.2,600000,119,"English","Sam Mendes"),
 # --- edge-case / boundary records (fictional, flagged by the warning engine) ---
 ("Edge Case: Zero-Rated Flop","Comedy",2010,0.0,5,60,"English","Test Director"),
 ("Edge Case: Perfect Ten, Few Votes","Drama",2020,10.0,3,95,"English","Test Director"),
 ("Edge Case: Marathon Epic","Drama|War",1990,7.0,1500,420,"English","Test Director"),
 ("Edge Case: Silent Short","Mystery",1925,6.5,800,5,"English","Test Director"),
 ("Edge Case: Unknown Votes","Sci-Fi",2023,7.2,0,100,"English",""),
]
recs = []
for i, (t, g, y, r, v, rt, lang, d) in enumerate(rows, 1):
    recs.append({"id": i, "title": t, "genres": g.split("|"), "year": y, "rating": r,
                 "votes": v, "runtime": rt, "language": lang, "director": d})
with open("../data/movies.json", "w", encoding="utf-8") as f:
    json.dump({"movies": recs}, f, indent=2, ensure_ascii=False)
with open("../data/seed_movies.csv", "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=["id","title","genres","year","rating","votes","runtime","language","director"])
    w.writeheader()
    for r in recs:
        w.writerow({**r, "genres": "|".join(r["genres"])})
print(len(recs), "records written")
