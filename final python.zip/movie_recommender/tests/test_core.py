import csv, json, sys, tempfile, unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from movierec.models import Movie, validate_record
from movierec.recommender import recommend, weighted_rating
from movierec.search import search
from movierec.storage import MovieStore, SEED_CSV
from movierec.summary import compute_summary, find_warnings
from movierec.importer import import_csv
from movierec.validation import parse_genre_selection
from movierec.exporter import export_markdown, export_audit_log, export_summary_csv


def make_store(tmp):
    return MovieStore(Path(tmp) / "m.json", Path(tmp) / "h.json", SEED_CSV)


class Tests(unittest.TestCase):
    def test_validate_ok_and_errors(self):
        r = validate_record({"title": "X", "genres": "action|Sci Fi", "year": 2000, "rating": 7})
        self.assertEqual(r["genres"], ["Action", "Sci-Fi"])
        for bad in ({"title": "", "genres": "Drama", "year": 2000, "rating": 5},
                    {"title": "X", "genres": "Nope", "year": 2000, "rating": 5},
                    {"title": "X", "genres": "Drama", "year": 1700, "rating": 5},
                    {"title": "X", "genres": "Drama", "year": 2000, "rating": 11},
                    {"title": "X", "genres": "Drama", "year": 2000, "rating": "abc"},
                    {"title": "X", "genres": "Drama", "year": 2000, "rating": 5, "runtime": 0}):
            with self.assertRaises(ValueError):
                validate_record(bad)

    def test_genre_parsing(self):
        self.assertEqual(parse_genre_selection("1, comedy 99 foo"), (["Action", "Comedy"], ["99", "foo"]))

    def test_recommend_any_all(self):
        with tempfile.TemporaryDirectory() as t:
            ms = make_store(t).movies
        any_ = recommend(ms, ["Sci-Fi", "Comedy"], "any", top_n=50)
        all_ = recommend(ms, ["Sci-Fi", "Comedy"], "all", top_n=50)
        self.assertGreater(len(any_), len(all_))
        self.assertTrue(all({"Sci-Fi", "Comedy"} <= set(r.movie.genres) for r in all_))
        scores = [r.score for r in any_]
        self.assertEqual(scores, sorted(scores, reverse=True))
        self.assertEqual(recommend(ms, [], "any"), [])
        self.assertEqual(recommend(ms, ["Sci-Fi"], min_rating=9.9), [])

    def test_weighted_rating_penalises_few_votes(self):
        a = Movie(1, "a", ["Drama"], 2020, 10.0, 3)
        b = Movie(2, "b", ["Drama"], 2020, 9.0, 2_000_000)
        self.assertLess(weighted_rating(a, 7.5), weighted_rating(b, 7.5))

    def test_persistence_roundtrip(self):
        with tempfile.TemporaryDirectory() as t:
            s = make_store(t); n = len(s.movies)
            s.add(Movie(0, "Persist Me", ["Drama"], 2024, 8.0, 100, 100))
            s2 = make_store(t)
            self.assertEqual(len(s2.movies), n + 1)
            self.assertIsNotNone(s2.find_duplicate("persist me", 2024))

    def test_missing_and_corrupt_file_recovery(self):
        with tempfile.TemporaryDirectory() as t:
            s = make_store(t)
            self.assertGreaterEqual(len(s.movies), 30)
            (Path(t) / "m.json").write_text("{not json", encoding="utf-8")
            s = make_store(t)
            self.assertGreaterEqual(len(s.movies), 30)
            self.assertIn("corrupted", s.notice)
            self.assertTrue(list(Path(t).glob("*.corrupt-*")))

    def test_search(self):
        with tempfile.TemporaryDirectory() as t:
            ms = make_store(t).movies
        self.assertTrue(all("nolan" in m.director.lower() for m in search(ms, "nolan")))
        self.assertTrue(all("Horror" in m.genres for m in search(ms, genre="Horror")))

    def test_summary_and_warnings(self):
        with tempfile.TemporaryDirectory() as t:
            ms = make_store(t).movies
        s = compute_summary(ms)
        self.assertEqual(s["total"], len(ms))
        self.assertEqual(compute_summary([]), {"total": 0})
        msgs = " ".join(m for _, m in find_warnings(ms))
        self.assertIn("rating is 0", msgs); self.assertIn("exceeds 240", msgs)

    def test_import_with_errors(self):
        with tempfile.TemporaryDirectory() as t:
            s = make_store(t)
            res = import_csv(s, Path(__file__).resolve().parent.parent / "data" / "legacy_import_sample.csv", t)
            self.assertEqual(res["added"], 3)
            self.assertEqual(len(res["errors"]), 4)
            self.assertEqual(res["duplicates"], ["Toy Story"])
            self.assertTrue(res["log"].exists())
            ids = [m.id for m in s.movies]
            self.assertEqual(len(ids), len(set(ids)))

    def test_exports(self):
        with tempfile.TemporaryDirectory() as t:
            ms = make_store(t).movies
            for p in (export_markdown(ms, t), export_audit_log(ms, t), export_summary_csv(ms, t)):
                self.assertTrue(p.exists() and p.stat().st_size > 0)

    def test_charts(self):
        from movierec.plotting import HAS_MPL, generate_charts
        if not HAS_MPL:
            self.skipTest("matplotlib missing")
        with tempfile.TemporaryDirectory() as t:
            ms = make_store(t).movies
            self.assertEqual(len(generate_charts(ms, t, recommend(ms, ["Action"]))), 5)


if __name__ == "__main__":
    unittest.main()
