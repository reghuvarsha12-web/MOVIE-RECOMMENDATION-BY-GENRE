#!/usr/bin/env python3
"""Entry point: python main.py"""
from movierec.ui import App

if __name__ == "__main__":
    App().run()
