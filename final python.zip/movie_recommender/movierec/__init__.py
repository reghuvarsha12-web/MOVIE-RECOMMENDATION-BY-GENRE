"""Movie Recommendation by Genre - FutureReady Hack Project #119."""
__version__ = "1.0.0"
