"""Terminal UI: ANSI styling, tables with pagination, and the menu loop."""
from __future__ import annotations

import os
import sys

from . import __version__
from .exporter import (export_audit_log, export_markdown, export_summary_csv, render_summary_text)
from .importer import import_csv
from .models import GENRES, Movie, validate_record
from .plotting import generate_charts
from .recommender import recommend
from .search import search
from .storage import REPORT_DIR, DATA_DIR, MovieStore
from .summary import compute_summary, find_warnings
from .validation import (UserCancelled, ask_float, ask_genres, ask_int, ask_str, ask_year,
                         ask_yes_no, show_genres)

USE_COLOR = sys.stdout.isatty() and os.environ.get("NO_COLOR") is None
PAGE_SIZE = 10


def c(text: str, code: str) -> str:
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text


def bold(t): return c(t, "1")
def green(t): return c(t, "32")
def yellow(t): return c(t, "33")
def red(t): return c(t, "31")
def cyan(t): return c(t, "36")


def clip(text: str, width: int) -> str:
    return text if len(text) <= width else text[:width - 1] + "…"


def banner() -> None:
    line = "=" * 58
    print(cyan(line))
    print(cyan("  🎬  MOVIE RECOMMENDATION BY GENRE") + f"   v{__version__}")
    print("  FutureReady Hack · Project #119 · AI, APIs & Smart Apps")
    print(cyan(line))


def print_table(movies: list, paginate: bool = True) -> None:
    if not movies:
        print(yellow("  No matching movies."))
        return
    head = f"  {'ID':>3}  {'Title':<32} {'Year':<5} {'Genres':<28} {'Rate':>4} {'Min':>4}"
    for start in range(0, len(movies), PAGE_SIZE):
        print(bold(head))
        print("  " + "-" * (len(head) - 2))
        for m in movies[start:start + PAGE_SIZE]:
            print(f"  {m.id:>3}  {clip(m.title, 32):<32} {m.year:<5} {clip(', '.join(m.genres), 28):<28} "
                  f"{m.rating:>4.1f} {m.runtime:>4}")
        shown = min(start + PAGE_SIZE, len(movies))
        print(f"  Showing {shown} of {len(movies)}")
        if paginate and shown < len(movies):
            if input("  [Enter] next page, [q] stop: ").strip().lower() == "q":
                break


def print_recs(recs: list) -> None:
    if not recs:
        print(yellow("  No movies matched those criteria. Try 'any' mode or lower the minimum rating."))
        return
    print(bold(f"\n  {'#':<3} {'Title':<34} {'Year':<5} {'Rating':>6} {'Score':>6}  Matched"))
    print("  " + "-" * 78)
    for i, r in enumerate(recs, 1):
        print(f"  {i:<3} {clip(r.movie.title, 34):<34} {r.movie.year:<5} {r.movie.rating:>6.1f} "
              f"{green(f'{r.score:>6.1f}')}  {', '.join(r.matched)}")


# ---------------------------------------------------------------- actions
class App:
    def __init__(self, store: MovieStore | None = None):
        self.store = store or MovieStore()
        self.last_recs: list = []

    def do_recommend(self) -> None:
        print(bold("\n-- Get Recommendations --  (type 'cancel' at any prompt to go back)"))
        genres = ask_genres()
        mode = "all" if len(genres) > 1 and ask_yes_no(
            "  Require ALL selected genres? (No = match any)", default=False) else "any"
        min_rating = ask_float("  Minimum rating 0-10 [default 0]: ", 0, 10, default=0.0)
        n = ask_int("  How many results (1-20) [default 5]: ", 1, 20, default=5)
        recs = recommend(self.store.movies, genres, mode=mode, min_rating=min_rating, top_n=n)
        print(f"\n  Top picks for {' + '.join(genres)} ({mode} mode):")
        print_recs(recs)
        self.last_recs = recs
        self.store.add_history(genres, mode, [r.movie.title for r in recs])

    def do_browse(self) -> None:
        print(bold("\n-- All Movies (sorted by rating) --"))
        print_table(sorted(self.store.movies, key=lambda m: (-m.rating, m.title)))

    def do_search(self) -> None:
        print(bold("\n-- Search --  (leave a field blank to skip it)"))
        kw = ask_str("  Keyword in title/director: ", allow_blank=True)
        genre = None
        if ask_yes_no("  Filter by a genre?", default=False):
            show_genres()
            genre = ask_genres("  Genre: ")[0]
        min_rating = ask_float("  Minimum rating [blank = any]: ", 0, 10, default=0.0)
        results = search(self.store.movies, kw, genre, min_rating=min_rating or None)
        print_table(results)

    def do_add(self) -> None:
        print(bold("\n-- Add Movie --  (type 'cancel' to abort)"))
        title = ask_str("  Title: ")
        year = ask_year("  Release year: ")
        dup = self.store.find_duplicate(title, year)
        if dup:
            print(red(f"  ! '{dup.title}' ({dup.year}) already exists as #{dup.id}."))
            return
        genres = ask_genres()
        rating = ask_float("  Rating 0-10: ", 0, 10)
        votes = ask_int("  Number of votes [default 0]: ", 0, 10**9, default=0)
        runtime = ask_int("  Runtime in minutes (1-600): ", 1, 600)
        language = ask_str("  Language [default English]: ", allow_blank=True) or "English"
        director = ask_str("  Director [optional]: ", allow_blank=True)
        movie = Movie.from_dict(validate_record({
            "title": title, "genres": genres, "year": year, "rating": rating, "votes": votes,
            "runtime": runtime, "language": language, "director": director}))
        saved = self.store.add(movie)
        print(green(f"  ✔ Saved '{saved.title}' as #{saved.id}."))

    def do_delete(self) -> None:
        print(bold("\n-- Delete Movie --"))
        mid = ask_int("  Movie ID to delete: ", 1, 10**9)
        mv = self.store.get(mid)
        if not mv:
            print(red(f"  ! No movie with ID {mid}."))
        elif ask_yes_no(f"  Delete '{mv.title}'?", default=False):
            self.store.remove(mid)
            print(green("  ✔ Deleted."))

    def do_summary(self) -> None:
        print()
        print(render_summary_text(self.store.movies))
        warns = find_warnings(self.store.movies)
        if warns:
            print(yellow(f"\n  ⚠ {sum(1 for w in warns if w[0]=='WARN')} warning(s) found - see menu option 10."))

    def do_charts(self) -> None:
        try:
            paths = generate_charts(self.store.movies, REPORT_DIR / "charts", self.last_recs)
        except RuntimeError as e:
            print(red(f"  ! {e}"))
            return
        print(green(f"  ✔ {len(paths)} chart(s) saved to {REPORT_DIR / 'charts'}"))
        for p in paths:
            print("    -", p.name)

    def do_export(self) -> None:
        md = export_markdown(self.store.movies, REPORT_DIR, self.last_recs)
        log = export_audit_log(self.store.movies, REPORT_DIR, self.store.load_history())
        gcsv = export_summary_csv(self.store.movies, REPORT_DIR)
        full = self.store.export_csv(REPORT_DIR / "movies_export.csv")
        print(green("  ✔ Exported:"))
        for p in (md, log, gcsv, full):
            print("    -", p)

    def do_import(self) -> None:
        print(bold("\n-- Bulk CSV Import --"))
        default = DATA_DIR / "legacy_import_sample.csv"
        raw = ask_str(f"  CSV path [Enter = {default.name}]: ", allow_blank=True)
        path = raw.strip('"\'') or str(default)
        try:
            res = import_csv(self.store, path, REPORT_DIR)
        except FileNotFoundError:
            print(red(f"  ! File not found: {path}"))
            return
        except (OSError, ValueError, UnicodeDecodeError) as e:
            print(red(f"  ! Could not read CSV: {e}"))
            return
        print(green(f"  ✔ Added {res['added']} movie(s)."))
        if res["errors"]:
            print(yellow(f"  ⚠ {len(res['errors'])} row(s) rejected:"))
            for n, msg in res["errors"][:10]:
                print(f"    Row {n}: {msg}")
        if res["duplicates"]:
            print(yellow(f"  ⚠ {len(res['duplicates'])} duplicate(s) skipped."))
        if res["log"]:
            print("  Detailed log:", res["log"])

    def do_warnings(self) -> None:
        warns = find_warnings(self.store.movies)
        print(bold("\n-- Data Quality Warnings --"))
        if not warns:
            print(green("  All clear."))
        for sev, msg in warns:
            print(f"  {red('WARN') if sev == 'WARN' else cyan('INFO')}  {msg}")

    def do_history(self) -> None:
        hist = self.store.load_history()
        print(bold("\n-- Recommendation History (last 10) --"))
        if not hist:
            print("  No requests yet.")
        for h in hist[-10:]:
            top = h["results"][0] if h["results"] else "no results"
            print(f"  {h['time']}  {'+'.join(h['genres']):<24} ({h['mode']})  top: {top}")

    # ---------------------------------------------------------------- loop
    MENU = [
        ("1", "Get recommendations by genre", "do_recommend"),
        ("2", "Browse all movies", "do_browse"),
        ("3", "Search movies", "do_search"),
        ("4", "Add a movie", "do_add"),
        ("5", "Delete a movie", "do_delete"),
        ("6", "Executive summary", "do_summary"),
        ("7", "Generate charts (PNG)", "do_charts"),
        ("8", "Export reports (MD / TXT / CSV)", "do_export"),
        ("9", "Bulk import from CSV", "do_import"),
        ("10", "Data quality warnings", "do_warnings"),
        ("11", "Recommendation history", "do_history"),
        ("0", "Exit", None),
    ]

    def run(self) -> None:
        banner()
        if self.store.notice:
            print(yellow(f"  ℹ {self.store.notice}"))
        print(f"  {len(self.store.movies)} movies loaded.")
        actions = {k: fn for k, _, fn in self.MENU}
        while True:
            print(bold("\n  MAIN MENU"))
            for k, label, _ in self.MENU:
                print(f"   {k:>2}. {label}")
            try:
                choice = input("\n  Choose an option: ").strip()
                if choice == "0":
                    break
                if choice not in actions:
                    print(red("  ! Invalid choice - enter a number from the menu."))
                    continue
                getattr(self, actions[choice])()
            except UserCancelled:
                print(yellow("  Cancelled."))
            except (EOFError, KeyboardInterrupt):
                print()
                break
            except Exception as e:  # last-resort guard so the demo never crashes
                print(red(f"  ! Unexpected error: {e}"))
        print(cyan("\n  Thanks for using Movie Recommendation by Genre. Goodbye! 🍿"))
