"""JSON/CSV persistence with corruption recovery."""
from __future__ import annotations

import csv
import datetime as dt
import json
import os
import shutil
import tempfile
from pathlib import Path

from .models import Movie, CSV_FIELDS

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
REPORT_DIR = BASE_DIR / "reports"
DEFAULT_DB = DATA_DIR / "movies.json"
SEED_CSV = DATA_DIR / "seed_movies.csv"
HISTORY_FILE = DATA_DIR / "history.json"


def _atomic_write_json(path: Path, payload) -> None:
    """Write to a temp file then rename, so a crash cannot leave a half-written file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def read_csv_movies(path: Path) -> tuple[list, list]:
    """Read a CSV; returns (valid Movie list, [(row_number, message), ...])."""
    movies, errors = [], []
    with open(path, newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        missing = {"title", "genres", "year", "rating"} - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"CSV is missing required column(s): {', '.join(sorted(missing))}")
        for n, row in enumerate(reader, start=2):  # row 1 is the header
            try:
                movies.append(Movie.from_dict(row))
            except ValueError as e:
                errors.append((n, str(e)))
    return movies, errors


class MovieStore:
    """In-memory list of movies backed by a JSON file."""

    def __init__(self, path: Path | str = DEFAULT_DB, history_path: Path | str = HISTORY_FILE,
                 seed_csv: Path | str = SEED_CSV):
        self.path = Path(path)
        self.history_path = Path(history_path)
        self.seed_csv = Path(seed_csv)
        self.movies: list[Movie] = []
        self.notice = ""  # set when recovery happened, shown at startup
        self.load()

    # ---------- loading / saving ----------
    def load(self) -> None:
        try:
            with open(self.path, encoding="utf-8") as f:
                data = json.load(f)
            items = data["movies"] if isinstance(data, dict) else data
            if not isinstance(items, list):
                raise ValueError("'movies' is not a list")
            loaded, skipped = [], 0
            for item in items:
                try:
                    loaded.append(Movie.from_dict(item))
                except (ValueError, AttributeError, TypeError):
                    skipped += 1
            self.movies = loaded
            if skipped:
                self.notice = f"{skipped} invalid record(s) in {self.path.name} were skipped."
        except FileNotFoundError:
            self._reseed("Data file not found - created a fresh one from the sample dataset.")
        except (json.JSONDecodeError, ValueError, KeyError, TypeError):
            stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
            backup = self.path.with_suffix(f".corrupt-{stamp}.json")
            try:
                shutil.copy(self.path, backup)
            except OSError:
                pass
            self._reseed(f"Data file was corrupted - backed up to {backup.name} and restored from sample data.")

    def _reseed(self, message: str) -> None:
        try:
            self.movies, _ = read_csv_movies(self.seed_csv)
        except (OSError, ValueError):
            self.movies = []
            message += " (Sample data unavailable; starting empty.)"
        self.notice = message
        self.save()

    def save(self) -> None:
        _atomic_write_json(self.path, {"movies": [m.to_dict() for m in self.movies]})

    def export_csv(self, path: Path | str) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=CSV_FIELDS)
            w.writeheader()
            for m in self.movies:
                w.writerow(m.to_csv_row())
        return path

    # ---------- CRUD ----------
    def next_id(self) -> int:
        return max((m.id for m in self.movies), default=0) + 1

    def find_duplicate(self, title: str, year: int) -> Movie | None:
        t = title.strip().lower()
        return next((m for m in self.movies if m.title.lower() == t and m.year == year), None)

    def add(self, movie: Movie) -> Movie:
        movie.id = self.next_id()
        self.movies.append(movie)
        self.save()
        return movie

    def remove(self, movie_id: int) -> Movie | None:
        for i, m in enumerate(self.movies):
            if m.id == movie_id:
                gone = self.movies.pop(i)
                self.save()
                return gone
        return None

    def get(self, movie_id: int) -> Movie | None:
        return next((m for m in self.movies if m.id == movie_id), None)

    # ---------- recommendation history ----------
    def load_history(self) -> list:
        try:
            with open(self.history_path, encoding="utf-8") as f:
                data = json.load(f)
            return data if isinstance(data, list) else []
        except (OSError, json.JSONDecodeError):
            return []

    def add_history(self, genres: list, mode: str, titles: list) -> None:
        hist = self.load_history()
        hist.append({"time": dt.datetime.now().isoformat(timespec="seconds"),
                     "genres": genres, "mode": mode, "results": titles})
        _atomic_write_json(self.history_path, hist[-200:])
