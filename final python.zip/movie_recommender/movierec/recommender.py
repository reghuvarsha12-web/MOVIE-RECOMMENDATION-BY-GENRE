"""Core recommendation engine: genre matching + weighted rating + recency."""
from __future__ import annotations

from dataclasses import dataclass

from .models import Movie, current_year

VOTE_THRESHOLD = 10_000  # votes needed before a rating is fully trusted


@dataclass
class Recommendation:
    movie: Movie
    score: float          # 0-100
    matched: list         # genres that matched the user's selection
    weighted_rating: float


def mean_rating(movies: list) -> float:
    return sum(m.rating for m in movies) / len(movies) if movies else 0.0


def weighted_rating(movie: Movie, global_mean: float, m: int = VOTE_THRESHOLD) -> float:
    """IMDb-style Bayesian average: shrinks ratings that have few votes toward the global mean."""
    v = movie.votes
    return (v / (v + m)) * movie.rating + (m / (v + m)) * global_mean


def recommend(movies: list, genres: list, mode: str = "any", min_rating: float = 0.0,
              year_from: int | None = None, year_to: int | None = None,
              max_runtime: int | None = None, top_n: int = 5,
              exclude_ids: set | None = None) -> list:
    """Return the top_n Recommendation objects for the selected genres.

    mode: 'any' = movie matches at least one chosen genre; 'all' = must match every chosen genre.
    Score = 60% weighted rating + 30% genre-match fraction + 10% recency.
    """
    if mode not in ("any", "all"):
        raise ValueError("mode must be 'any' or 'all'")
    wanted = set(genres)
    if not wanted:
        return []
    exclude_ids = exclude_ids or set()
    gmean = mean_rating(movies)
    now = current_year()
    results = []
    for mv in movies:
        if mv.id in exclude_ids:
            continue
        matched = [g for g in mv.genres if g in wanted]
        if not matched or (mode == "all" and len(matched) < len(wanted)):
            continue
        if mv.rating < min_rating:
            continue
        if year_from is not None and mv.year < year_from:
            continue
        if year_to is not None and mv.year > year_to:
            continue
        if max_runtime is not None and mv.runtime > max_runtime:
            continue
        wr = weighted_rating(mv, gmean)
        match_frac = len(matched) / len(wanted)
        recency = max(0.0, 1 - (now - mv.year) / 60)  # newer films get a small boost
        score = 100 * (0.6 * wr / 10 + 0.3 * match_frac + 0.1 * recency)
        results.append(Recommendation(mv, round(score, 1), matched, round(wr, 2)))
    results.sort(key=lambda r: (-r.score, r.movie.title))
    return results[:max(0, top_n)]
