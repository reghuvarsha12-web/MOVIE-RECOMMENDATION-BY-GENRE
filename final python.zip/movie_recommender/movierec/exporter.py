"""Multi-format report export: Markdown, plain-text audit log, CSV."""
from __future__ import annotations

import csv
import datetime as dt
from pathlib import Path

from .summary import compute_summary, find_warnings


def _stamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


def render_summary_text(movies: list) -> str:
    s = compute_summary(movies)
    if s["total"] == 0:
        return "No records available."
    lines = [
        "EXECUTIVE SUMMARY",
        "=" * 52,
        f"Total movies        : {s['total']}",
        f"Year range          : {s['year_range'][0]} - {s['year_range'][1]}",
        f"Average rating      : {s['avg_rating']:.2f} / 10   [{s['status']}]",
        f"Average runtime     : {s['avg_runtime']:.0f} min",
        f"Total votes         : {s['total_votes']:,}",
        f"Most common genre   : {s['most_common_genre']}",
        f"Best-rated genre    : {s['best_rated_genre']} ({s['avg_by_genre'][s['best_rated_genre']]:.2f})",
        f"Rating trend        : {s['trend']}",
        "",
        "Top 5 (vote-weighted rating):",
    ]
    for i, m in enumerate(s["top5"], 1):
        lines.append(f"  {i}. {m.title} ({m.year}) - {m.rating}")
    lines += ["", "Genre breakdown (count / avg rating):"]
    for g, c in s["genre_count"].items():
        lines.append(f"  {g:<10} {c:>3}   {s['avg_by_genre'][g]:.2f}")
    lines += ["", "Languages: " + ", ".join(f"{k} ({v})" for k, v in s["languages"].items())]
    return "\n".join(lines)


def export_markdown(movies: list, out_dir: Path | str, recs: list | None = None) -> Path:
    s = compute_summary(movies)
    out = Path(out_dir) / f"report_{_stamp()}.md"
    out.parent.mkdir(parents=True, exist_ok=True)
    md = ["# Movie Recommendation Report", f"_Generated {dt.datetime.now():%Y-%m-%d %H:%M}_", ""]
    if s["total"]:
        md += ["## Summary", "", "| Metric | Value |", "|---|---|",
               f"| Total movies | {s['total']} |", f"| Average rating | {s['avg_rating']:.2f} ({s['status']}) |",
               f"| Average runtime | {s['avg_runtime']:.0f} min |", f"| Most common genre | {s['most_common_genre']} |",
               f"| Best-rated genre | {s['best_rated_genre']} |", f"| Trend | {s['trend']} |", "",
               "## Genre Breakdown", "", "| Genre | Count | Avg rating |", "|---|---|---|"]
        md += [f"| {g} | {c} | {s['avg_by_genre'][g]:.2f} |" for g, c in s["genre_count"].items()]
        md += ["", "## Top 5 (vote-weighted rating)", ""]
        md += [f"{i}. **{m.title}** ({m.year}) - {m.rating}" for i, m in enumerate(s["top5"], 1)]
    if recs:
        md += ["", "## Latest Recommendations", "", "| # | Title | Year | Score | Matched genres |", "|---|---|---|---|---|"]
        md += [f"| {i} | {r.movie.title} | {r.movie.year} | {r.score} | {', '.join(r.matched)} |" for i, r in enumerate(recs, 1)]
    warns = find_warnings(movies)
    if warns:
        md += ["", "## Warnings", ""] + [f"- **{sev}** {msg}" for sev, msg in warns]
    out.write_text("\n".join(md) + "\n", encoding="utf-8")
    return out


def export_audit_log(movies: list, out_dir: Path | str, history: list | None = None) -> Path:
    out = Path(out_dir) / f"audit_{_stamp()}.txt"
    out.parent.mkdir(parents=True, exist_ok=True)
    parts = [f"AUDIT LOG - generated {dt.datetime.now():%Y-%m-%d %H:%M:%S}", "", render_summary_text(movies), "",
             "WARNINGS", "-" * 52]
    warns = find_warnings(movies)
    parts += [f"[{sev}] {msg}" for sev, msg in warns] if warns else ["None"]
    parts += ["", "RECENT RECOMMENDATION REQUESTS", "-" * 52]
    if history:
        for h in history[-20:]:
            parts.append(f"{h['time']}  genres={'/'.join(h['genres'])} mode={h['mode']} -> {', '.join(h['results']) or 'no results'}")
    else:
        parts.append("None")
    out.write_text("\n".join(parts) + "\n", encoding="utf-8")
    return out


def export_summary_csv(movies: list, out_dir: Path | str) -> Path:
    s = compute_summary(movies)
    out = Path(out_dir) / f"genre_summary_{_stamp()}.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["genre", "count", "avg_rating"])
        if s["total"]:
            for g, c in s["genre_count"].items():
                w.writerow([g, c, f"{s['avg_by_genre'][g]:.2f}"])
    return out
