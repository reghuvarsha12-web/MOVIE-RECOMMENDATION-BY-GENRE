"""Keyword and category filtering over stored records."""
from __future__ import annotations

from .models import Movie


def search(movies: list, keyword: str = "", genre: str | None = None,
           year_from: int | None = None, year_to: int | None = None,
           min_rating: float | None = None, language: str | None = None) -> list:
    kw = keyword.strip().lower()
    out = []
    for m in movies:
        if kw and kw not in m.title.lower() and kw not in m.director.lower():
            continue
        if genre and genre not in m.genres:
            continue
        if year_from is not None and m.year < year_from:
            continue
        if year_to is not None and m.year > year_to:
            continue
        if min_rating is not None and m.rating < min_rating:
            continue
        if language and language.lower() != m.language.lower():
            continue
        out.append(m)
    return sorted(out, key=lambda m: (-m.rating, m.title))
