"""Centralised, crash-proof terminal input helpers. Each loops until the input is valid."""
from __future__ import annotations

from .models import GENRES, normalize_genre, MIN_YEAR, current_year


class UserCancelled(Exception):
    """Raised when the user types 'cancel' at a prompt that allows it."""


def _read(prompt: str, allow_cancel: bool = True) -> str:
    raw = input(prompt).strip()
    if allow_cancel and raw.lower() == "cancel":
        raise UserCancelled()
    return raw


def ask_str(prompt: str, min_len: int = 1, max_len: int = 100, allow_blank: bool = False) -> str:
    while True:
        v = _read(prompt)
        if not v and allow_blank:
            return ""
        if len(v) < min_len:
            print("  ! Input cannot be blank.")
        elif len(v) > max_len:
            print(f"  ! Too long (max {max_len} characters).")
        else:
            return v


def ask_int(prompt: str, lo: int, hi: int, default: int | None = None) -> int:
    while True:
        v = _read(prompt)
        if not v and default is not None:
            return default
        try:
            n = int(v)
        except ValueError:
            print("  ! Please enter a whole number.")
            continue
        if lo <= n <= hi:
            return n
        print(f"  ! Value must be between {lo} and {hi}.")


def ask_float(prompt: str, lo: float, hi: float, default: float | None = None) -> float:
    while True:
        v = _read(prompt)
        if not v and default is not None:
            return default
        try:
            n = float(v)
        except ValueError:
            print("  ! Please enter a number (e.g. 7.5).")
            continue
        if n != n or n in (float("inf"), float("-inf")):
            print("  ! Not a valid number.")
        elif lo <= n <= hi:
            return n
        else:
            print(f"  ! Value must be between {lo} and {hi}.")


def ask_yes_no(prompt: str, default: bool = False) -> bool:
    while True:
        v = _read(prompt + (" [Y/n]: " if default else " [y/N]: "), allow_cancel=False).lower()
        if not v:
            return default
        if v in ("y", "yes"):
            return True
        if v in ("n", "no"):
            return False
        print("  ! Please answer y or n.")


def parse_genre_selection(raw: str) -> tuple[list, list]:
    """Accept numbers or names separated by commas/spaces. Returns (valid, invalid_tokens)."""
    valid, bad = [], []
    for tok in raw.replace(",", " ").split():
        if tok.isdigit() and 1 <= int(tok) <= len(GENRES):
            g = GENRES[int(tok) - 1]
        else:
            g = normalize_genre(tok)
        if g is None:
            bad.append(tok)
        elif g not in valid:
            valid.append(g)
    return valid, bad


def show_genres() -> None:
    print("  Available genres:")
    for i in range(0, len(GENRES), 4):
        row = GENRES[i:i + 4]
        print("   " + "".join(f"{i + j + 1:>2}. {g:<12}" for j, g in enumerate(row)))


def ask_genres(prompt: str = "  Pick genre(s) by number or name (e.g. 1,6 or action comedy): ") -> list:
    show_genres()
    while True:
        valid, bad = parse_genre_selection(_read(prompt))
        if bad:
            print(f"  ! Unrecognised: {', '.join(bad)}")
        elif not valid:
            print("  ! Select at least one genre.")
        else:
            return valid


def ask_year(prompt: str, default: int | None = None) -> int:
    return ask_int(prompt, MIN_YEAR, current_year() + 1, default)
