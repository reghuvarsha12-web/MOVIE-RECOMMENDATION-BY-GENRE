"""Data model and schema validation for movie records."""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, asdict, field

GENRES = [
    "Action", "Adventure", "Animation", "Biography", "Comedy", "Crime",
    "Drama", "Family", "Fantasy", "Horror", "Musical", "Mystery",
    "Romance", "Sci-Fi", "Thriller", "War",
]
MIN_YEAR = 1888
MAX_RATING = 10.0
MAX_RUNTIME = 600
CSV_FIELDS = ["id", "title", "genres", "year", "rating", "votes", "runtime", "language", "director"]


def current_year() -> int:
    return _dt.date.today().year


@dataclass
class Movie:
    id: int
    title: str
    genres: list = field(default_factory=list)
    year: int = 2000
    rating: float = 0.0
    votes: int = 0
    runtime: int = 90
    language: str = "English"
    director: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    def to_csv_row(self) -> dict:
        d = self.to_dict()
        d["genres"] = "|".join(self.genres)
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "Movie":
        """Build a Movie from a dict (JSON or CSV row). Raises ValueError listing all problems."""
        clean = validate_record(d)
        return cls(**clean)


def normalize_genre(name: str) -> str | None:
    """Case-insensitive match against the known genre list."""
    key = name.strip().lower().replace("scifi", "sci-fi").replace("sci fi", "sci-fi")
    for g in GENRES:
        if g.lower() == key:
            return g
    return None


def validate_record(d: dict) -> dict:
    """Validate and coerce a raw record. Raises ValueError with every issue found."""
    errors = []
    out = {}

    def get(k, default=""):
        v = d.get(k, default)
        return "" if v is None else v

    try:
        out["id"] = int(str(get("id", 0)).strip() or 0)
    except ValueError:
        errors.append("id must be an integer")
        out["id"] = 0

    title = str(get("title")).strip()
    if not title:
        errors.append("title is required")
    elif len(title) > 100:
        errors.append("title longer than 100 characters")
    out["title"] = title

    raw_g = get("genres", [])
    if isinstance(raw_g, str):
        raw_g = [g for g in raw_g.replace(",", "|").split("|") if g.strip()]
    genres = []
    unknown = False
    for g in raw_g:
        ng = normalize_genre(str(g))
        if ng is None:
            errors.append(f"unknown genre '{g}'")
            unknown = True
        elif ng not in genres:
            genres.append(ng)
    if not genres and not unknown:
        errors.append("at least one genre is required")
    out["genres"] = genres

    try:
        year = int(str(get("year")).strip())
        if not MIN_YEAR <= year <= current_year() + 1:
            errors.append(f"year must be {MIN_YEAR}-{current_year() + 1}")
        out["year"] = year
    except ValueError:
        errors.append("year must be a whole number")
        out["year"] = 0

    try:
        rating = float(str(get("rating")).strip())
        if not 0 <= rating <= MAX_RATING:
            errors.append("rating must be between 0 and 10")
        out["rating"] = round(rating, 2)
    except ValueError:
        errors.append("rating must be a number")
        out["rating"] = 0.0

    try:
        votes = int(float(str(get("votes", 0)).strip() or 0))
        if votes < 0:
            errors.append("votes cannot be negative")
        out["votes"] = votes
    except ValueError:
        errors.append("votes must be a whole number")
        out["votes"] = 0

    try:
        runtime = int(float(str(get("runtime", 90)).strip()))
        if not 1 <= runtime <= MAX_RUNTIME:
            errors.append(f"runtime must be 1-{MAX_RUNTIME} minutes")
        out["runtime"] = runtime
    except ValueError:
        errors.append("runtime must be a whole number")
        out["runtime"] = 0

    out["language"] = str(get("language", "English")).strip() or "English"
    out["director"] = str(get("director")).strip()

    if errors:
        raise ValueError("; ".join(errors))
    return out
