"""Matplotlib chart generation (headless-safe, with graceful fallback)."""
from __future__ import annotations

from pathlib import Path

from .summary import compute_summary

try:  # fall back gracefully if matplotlib is not installed
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    HAS_MPL = True
except ImportError:  # pragma: no cover
    HAS_MPL = False


def generate_charts(movies: list, out_dir: Path | str, recs: list | None = None) -> list:
    """Create PNG charts in out_dir and return their paths. Raises RuntimeError without matplotlib."""
    if not HAS_MPL:
        raise RuntimeError("matplotlib is not installed. Run: pip install matplotlib")
    if not movies:
        raise RuntimeError("No data to plot.")
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    s = compute_summary(movies)
    paths = []

    # 1. Genre distribution
    fig, ax = plt.subplots(figsize=(9, 5))
    g, c = list(s["genre_count"]), list(s["genre_count"].values())
    ax.barh(g[::-1], c[::-1], color="#4C78A8")
    ax.set_title("Movies per Genre"); ax.set_xlabel("Number of movies")
    fig.tight_layout(); p = out_dir / "genre_distribution.png"; fig.savefig(p, dpi=120); plt.close(fig); paths.append(p)

    # 2. Average rating by genre
    fig, ax = plt.subplots(figsize=(9, 5))
    g, r = list(s["avg_by_genre"]), list(s["avg_by_genre"].values())
    ax.bar(g, r, color="#F58518")
    ax.set_ylim(0, 10); ax.set_title("Average Rating by Genre"); ax.set_ylabel("Avg rating")
    plt.setp(ax.get_xticklabels(), rotation=45, ha="right")
    fig.tight_layout(); p = out_dir / "avg_rating_by_genre.png"; fig.savefig(p, dpi=120); plt.close(fig); paths.append(p)

    # 3. Trend: average rating by decade
    fig, ax = plt.subplots(figsize=(9, 5))
    d, r = list(s["avg_by_decade"]), list(s["avg_by_decade"].values())
    ax.plot([f"{x}s" for x in d], r, marker="o", color="#54A24B")
    ax.set_ylim(0, 10); ax.set_title("Average Rating Trend by Decade"); ax.set_ylabel("Avg rating"); ax.grid(alpha=.3)
    fig.tight_layout(); p = out_dir / "rating_trend_by_decade.png"; fig.savefig(p, dpi=120); plt.close(fig); paths.append(p)

    # 4. Rating histogram
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.hist([m.rating for m in movies], bins=[i / 2 for i in range(0, 21)], color="#B279A2", edgecolor="white")
    ax.set_title("Rating Distribution"); ax.set_xlabel("Rating"); ax.set_ylabel("Movies")
    fig.tight_layout(); p = out_dir / "rating_histogram.png"; fig.savefig(p, dpi=120); plt.close(fig); paths.append(p)

    # 5. Latest recommendation scores (optional)
    if recs:
        fig, ax = plt.subplots(figsize=(9, 5))
        ax.barh([r.movie.title[:35] for r in recs][::-1], [r.score for r in recs][::-1], color="#E45756")
        ax.set_xlim(0, 100); ax.set_title("Latest Recommendation Scores"); ax.set_xlabel("Score (0-100)")
        fig.tight_layout(); p = out_dir / "latest_recommendations.png"; fig.savefig(p, dpi=120); plt.close(fig); paths.append(p)
    return paths
