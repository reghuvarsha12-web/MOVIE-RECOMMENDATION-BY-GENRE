"""Bulk CSV import with row-by-row error log."""
from __future__ import annotations

import datetime as dt
from pathlib import Path

from .storage import MovieStore, read_csv_movies


def import_csv(store: MovieStore, csv_path: Path | str, log_dir: Path | str) -> dict:
    """Import valid rows, skip invalid/duplicate ones, write a log. Returns a result dict."""
    csv_path = Path(csv_path)
    movies, errors = read_csv_movies(csv_path)  # may raise OSError / ValueError (handled by caller)
    added, dupes = 0, []
    for m in movies:
        if store.find_duplicate(m.title, m.year):
            dupes.append(m.title)
            continue
        m.id = store.next_id()  # always assign a fresh, unique id
        store.movies.append(m)
        added += 1
    if added:
        store.save()
    log_path = None
    if errors or dupes:
        log_path = Path(log_dir) / f"import_errors_{dt.datetime.now():%Y%m%d_%H%M%S}.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        lines = [f"Import of {csv_path.name} at {dt.datetime.now():%Y-%m-%d %H:%M:%S}",
                 f"Added: {added}  Rejected: {len(errors)}  Duplicates skipped: {len(dupes)}", ""]
        lines += [f"Row {n}: {msg}" for n, msg in errors]
        lines += [f"Duplicate skipped: {t}" for t in dupes]
        log_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {"added": added, "errors": errors, "duplicates": dupes, "log": log_path}
