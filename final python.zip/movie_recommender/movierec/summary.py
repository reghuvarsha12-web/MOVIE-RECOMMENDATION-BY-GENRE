"""Executive summary metrics and threshold warnings."""
from __future__ import annotations

from collections import Counter, defaultdict

from .models import Movie, current_year
from .recommender import mean_rating, weighted_rating


def compute_summary(movies: list) -> dict:
    n = len(movies)
    if n == 0:
        return {"total": 0}
    genre_count, genre_ratings, decade_ratings, lang = Counter(), defaultdict(list), defaultdict(list), Counter()
    for m in movies:
        for g in m.genres:
            genre_count[g] += 1
            genre_ratings[g].append(m.rating)
        decade_ratings[m.year // 10 * 10].append(m.rating)
        lang[m.language] += 1
    avg_by_genre = {g: sum(v) / len(v) for g, v in genre_ratings.items()}
    avg_by_decade = {d: sum(v) / len(v) for d, v in sorted(decade_ratings.items())}
    avg = sum(m.rating for m in movies) / n
    decades = list(avg_by_decade)
    trend = "n/a"
    if len(decades) >= 2:
        diff = avg_by_decade[decades[-1]] - avg_by_decade[decades[0]]
        trend = ("rising" if diff > 0.2 else "falling" if diff < -0.2 else "flat") + \
                f" ({decades[0]}s {avg_by_decade[decades[0]]:.2f} -> {decades[-1]}s {avg_by_decade[decades[-1]]:.2f})"
    status = "Excellent" if avg >= 8 else "Good" if avg >= 7 else "Mixed" if avg >= 6 else "Weak"
    best_genre = max(avg_by_genre, key=lambda g: (avg_by_genre[g], genre_count[g]))
    return {
        "total": n,
        "avg_rating": avg,
        "avg_runtime": sum(m.runtime for m in movies) / n,
        "total_votes": sum(m.votes for m in movies),
        "genre_count": dict(genre_count.most_common()),
        "avg_by_genre": dict(sorted(avg_by_genre.items(), key=lambda kv: -kv[1])),
        "avg_by_decade": avg_by_decade,
        "languages": dict(lang.most_common()),
        "top5": sorted(movies, key=lambda m: (-weighted_rating(m, mean_rating(movies)), m.title))[:5],
        "most_common_genre": next(iter(genre_count.most_common(1)))[0],
        "best_rated_genre": best_genre,
        "trend": trend,
        "status": status,
        "year_range": (min(m.year for m in movies), max(m.year for m in movies)),
    }


def find_warnings(movies: list) -> list:
    """Return (severity, message) tuples. severity is 'WARN' or 'INFO'."""
    out = []
    seen = {}
    for m in movies:
        tag = f"#{m.id} '{m.title}'"
        if m.rating == 0:
            out.append(("WARN", f"{tag}: rating is 0 (anomalous or unrated)"))
        if m.rating < 4 and m.votes >= 100_000:
            out.append(("WARN", f"{tag}: very low rating with many votes"))
        if m.rating >= 9.5 and m.votes < 1000:
            out.append(("WARN", f"{tag}: near-perfect rating from only {m.votes} votes - unreliable"))
        if m.votes == 0:
            out.append(("INFO", f"{tag}: no votes recorded"))
        elif m.votes < 1000 and m.rating < 9.5:
            out.append(("INFO", f"{tag}: low vote count ({m.votes})"))
        if m.runtime > 240:
            out.append(("WARN", f"{tag}: runtime {m.runtime} min exceeds 240"))
        if m.runtime < 20:
            out.append(("WARN", f"{tag}: runtime {m.runtime} min is unusually short"))
        if m.year > current_year():
            out.append(("INFO", f"{tag}: release year {m.year} is in the future"))
        key = (m.title.lower(), m.year)
        if key in seen:
            out.append(("WARN", f"{tag}: duplicate of #{seen[key]}"))
        seen[key] = m.id
    return out
